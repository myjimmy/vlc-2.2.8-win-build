#ifndef __CACA_DISPLAY_H__
#define __CACA_DISPLAY_H__

#include <ruby.h>

extern VALUE cDisplay;
extern void Init_caca_display(VALUE);

#endif
