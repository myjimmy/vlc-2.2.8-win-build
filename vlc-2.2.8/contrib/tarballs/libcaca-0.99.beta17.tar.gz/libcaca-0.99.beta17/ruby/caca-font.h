#ifndef __CACA_FONT_H__
#define __CACA_FONT_H__

#include <ruby.h>

extern VALUE cFont;
extern void Init_caca_font(VALUE);

#endif
