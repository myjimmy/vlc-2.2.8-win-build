#if defined _WIN64
#   define CACA_TYPES 4
#else
#   define CACA_TYPES 3
#endif
#include "../caca/caca_types.h.in"